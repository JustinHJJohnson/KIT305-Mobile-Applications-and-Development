package com.example.assignment_4_mach_1_marks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
