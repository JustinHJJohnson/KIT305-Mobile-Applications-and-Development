//
//  WeekTableViewCell.swift
//  Assignment3
//
//  Created by Justin Johnson on 15/5/21.
//

import UIKit

class WeekUITableViewCell: UITableViewCell
{
    @IBOutlet var weekLabel: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
