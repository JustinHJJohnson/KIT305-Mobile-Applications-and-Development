package au.edu.utas.kit305.assignment2

class Grades (
    var week1 : Int? = 0,
    var week2 : Int? = 0,
    var week3 : Int? = 0,
    var week4 : Int? = 0,
    var week5 : Int? = 0,
    var week6 : Int? = 0,
    var week7 : Int? = 0,
    var week8 : Int? = 0,
    var week9 : Int? = 0,
    var week10 : Int? = 0,
    var week11 : Int? = 0,
    var week12 : Int? = 0
)