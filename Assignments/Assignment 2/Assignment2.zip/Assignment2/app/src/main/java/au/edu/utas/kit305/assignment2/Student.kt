package au.edu.utas.kit305.assignment2

class Student (
    var studentID : String? = null,
    var firstName : String? = null,
    var lastName : String? = null,
    var image: String? = null
)